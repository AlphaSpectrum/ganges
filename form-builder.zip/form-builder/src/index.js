import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'jquery/dist/jquery.min';
import 'bootstrap/dist/js/bootstrap.bundle';
import registerServiceWorker from './registerServiceWorker';
import FormEditor from './components/FormEditor';
import Checkbox from './components/Checkbox';
import CheckboxEditor from './components/CheckboxEditor';

/*
const testInputs = [
    {
        input: {
            id: 'exampleInputId',
            label: 'Example Enabled Input',
            placeholder: 'Placeholder'
        }
    },
    {
        input: {
            id: 'exampleInputId2',
            label: 'Example Disabled Input',
            placeholder: 'Placeholder',
            disabled: true
        }
    },
    {
        button: {
            id: 'exampleButtonId',
            label: 'Button Medium Enabled',
            color: 'blue'
        }
    },
    {
        button: {
            id: 'exampleButtonId2',
            label: 'Button Small Enabled',
            color: 'yellow',
            size: 'sm'
        }
    },
    {
        button: {
            id: 'exampleButton3',
            label: 'Button Large Enabled',
            color: 'green',
            size: 'lg'
        }
    },
    {
        button: {
            id: 'exampleButton4',
            label: 'Button Medium Disabled',
            disabled: true
        }
    },
    {
        checkbox: {
            id: 'exampleCheckboxId',
            label: 'Example Checkbox 1'
        }

    },
    {
        checkbox: {
            id: 'exampleCheckboxId2',
            label: 'Example Checkbox 2'
        }

    },
    {
        checkbox: {
            id: 'exampleCheckboxId3',
            label: 'Example Checkbox Disabled',
            disabled: true
        }

    },
    {
        checkbox: {
            id: 'exampleCheckboxId4',
            label: 'Example Checkbox Checked',
            checked: true
        }

    },
    {
        radio: {
            id: 'exampleRadio',
            label: 'Example Radio 1',
            name: 'radioGroup1'
        }
    },
    {
        radio: {
            id: 'exampleRadio2',
            label: 'Example Radio 2',
            name: 'radioGroup1'
        }
    },
    {
        radio: {
            id: 'exampleRadio3',
            label: 'Example Radio Disabled',
            name: 'radioGroup2',
            disabled: true
        }
    },
    {
        textarea: {
            id: 'exampleTextarea',
            label: 'Normal Textarea',
        }
    },
    {
        select: {
            id: 'exampleSelect',
            label: 'Example Select',
            optionList: {
                a: 'A',
                b: 'B',
                c: 'C',
                d: 'D'
            }
        }
    },
    {
        select: {
            id: 'exampleSelect2',
            label: 'Example Select Multiple',
            optionList: {
                a: 'A',
                b: 'B',
                c: 'C',
                d: 'D'
            },
            multiple: true
        }
    }

];

ReactDOM.render(
    <App id='form1'
         attributes={testInputs}
         title='Form Title'
         description='This is a description'
    />, document.getElementById('root')
);
*/

ReactDOM.render(<FormEditor/>, document.getElementById('root'));

registerServiceWorker();