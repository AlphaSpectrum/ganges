/**
 * @author Alan Campos
 * @version 1.0.0
 */

/**
 * Gets the time in miliseconds and perform a set of algebraic operations.
 * @returns {number} The result of the operations.
 * @since 1.0.0
 * @public
 */
export function generateUId() {
	return Math.ceil(new Date().getTime() / 11);
}

/**
 * Gets the time in miliseconds and adds a randomly generate number to the result.
 * @param {number} int - The integer to divide the operation by.
 * @returns {number} The result of the operations.
 * @since 1.0.0
 * @public
 */
export function generateUIdWithRandom() {
	return Math.ceil(new Date().getTime() + Math.floor(Math.random()));
}

/**
 * Extracts each data attribute from the dataset array and applies it to the element.
 * @param {string} elementId - The id of the element to apply the data.
 * @param {array} dataset - The array containing objects of contextual data.
 * @since 1.0.0
 * @public
 */
export function applyDataset(elementId, dataset) {
	for (let i in dataset) {
		// Get the index named "name" and append its value to the string `data-`
		// and set it as the attribute's name.
		// Similarly, get the value from the value index, and set it as the
		// attribute's value.
		document.getElementById(elementId).setAttribute('data-' + dataset[i].name, dataset[i].value);
	}
}

/**
 * Sets the disabled state of the element identified by its id.
 * @param {string} elementId - The id of the element.
 * @param {boolean} state - A boolean value representing whether its disabled state is true or false.
 * @since 1.0.0
 * @public
 */
export function setStateForDisabled(elementId, state) {
	const htmlElement = document.getElementById(elementId);
	if (htmlElement === null) {
		throw new Error(`Element with id "${elementId}" not found.`);
	} else {
		htmlElement.disabled = state;
	}
}


/**
 * Sets the checked state of the element identified by its id.
 * @param {string} elementId - The id of the element.
 * @param {boolean} state - A boolean value representing whether its checked state is true or false.
 * @since 1.0.0
 * @public
 */
export function setStateForChecked(elementId, state) {
	const htmlElement = document.getElementById(elementId);
	if (htmlElement === null) {
		throw new Error(`Element with id "${elementId}" not found.`);
	} else {
		htmlElement.checked = state;
	}
}