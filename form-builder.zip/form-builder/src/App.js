import React from 'react';
import Radio from './components/radio';
import Checkbox from './components/checkbox';
import Select from './components/select';
import Textarea from './components/textarea';
import Input from './components/input';
import Button from './components/button';

class App extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			id: this.props.id,
			attributes: this.props.attributes,
			title: this.props.title,
			description: this.props.description,
		};

		this.mapObjectToComponent = this.mapObjectToComponent.bind(this);
		this.objectToComponentList = this.objectToComponentList.bind(this);
	}

	mapObjectToComponent(componentName, object) {
		switch (componentName) {
		case 'input':
			return <Input key={object.id} attributes={object}/>;
		case 'button':
			return <Button key={object.id} attributes={object}/>;
		case 'radio':
			return <Radio key={object.id} attributes={object}/>;
		case 'select':
			return <Select key={object.id} attributes={object}/>;
		case 'textarea':
			return <Textarea key={object.id} attributes={object}/>;
		case 'checkbox':
			return <Checkbox key={object.id} attributes={object}/>;
		default: return null;
		}
	}

	objectToComponentList(object) {
		let list = [];

		for (let i in object) {
			for (let j in object[i]) {
				list.push(this.mapObjectToComponent(j, object[i][j]));
			}
		}

		return list;
	}

	//TODO: Implement an ajax call for submission and retrieving the form's attributes.

	render() {
		let componentList = this.objectToComponentList(this.state.attributes);

		return (
			<form id={this.state.id}>
				<h3 className='lead'>{this.state.title}</h3>
				<p>{this.state.description}</p>
				{componentList}
			</form>
		);
	}
}

export default App;