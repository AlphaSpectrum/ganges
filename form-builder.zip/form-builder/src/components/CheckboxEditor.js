/**
 * @author Alan Campos
 * @version 1.0.0
 */

import React from 'react';
import PropTypes from 'prop-types';
import { generateUIdWithRandom } from '../utils';
import Checkbox from './Checkbox';
import Input from './Input';

/**
 * Displays a card containing a preview of the checkbox's current properties, along with
 * inputs that allow you to change the button's attributes such as id, label, name and value.
 * The changes are applied live so the user can see what it will look like in production.
 */
class CheckboxEditor extends React.Component {
  shouldComponentUpdate(nextProps) {
    const prevProps = this.props;
    const diffId = prevProps.id !== nextProps.id;
    const diffLabel = prevProps.label !== nextProps.label;
    const diffName = prevProps.name !== nextProps.name;
    const diffValue = prevProps.value !== nextProps.value;
    return diffId || diffLabel || diffName || diffValue;
  }

  render() {
    const uid = generateUIdWithRandom();
    const {
      id,
      label,
      name,
      value,
      onChange,
    } = this.props;

    return (
      <div className="card m-3" style={{ width: `${20}rem` }}>
        <div
          className="card-header text-center"
          data-toggle="collapse"
          data-target={`#collapse${uid}`}
        >
          <Checkbox
            id={id}
            label={label}
            name={name}
            value={value}
          />
        </div>
        <ul className="list-group list-group-flush collapse show" id={`collapse${uid}`}>
          <li className="list-group-item">
            <Input
              id={`idForCheckboxIdChange${uid}`}
              label="ID"
              value={id}
              dataset={[
							       { name: 'state-target', value: 'id' },
							       { name: 'component-target', value: id },
						       ]}
              onChange={onChange}
            />
          </li>
          <li className="list-group-item">
            <Input
              id={`idForCheckboxLabelChange${uid}`}
              label="Label"
              value={label}
              dataset={[
							       { name: 'state-target', value: 'label' },
							       { name: 'component-target', value: id },
						       ]}
              onChange={onChange}
            />
          </li>
          <li className="list-group-item">
            <Input
              id={`idForCheckboxNameChange${uid}`}
              label="Name"
              placeholder="Name for this checkbox"
              value={name}
              dataset={[
							       { name: 'state-target', value: 'name' },
							       { name: 'component-target', value: id },
						       ]}
              onChange={onChange}
            />
          </li>
          <li className="list-group-item">
            <Input
              id={`idForCheckboxValueChange${uid}`}
              label="Checkbox Value"
              placeholder="checked"
              value={value}
              dataset={[
							       { name: 'state-target', value: 'value' },
							       { name: 'component-target', value: id },
						       ]}
              onChange={onChange}
            />
          </li>
        </ul>
      </div>
    );
  }
}

/**
 * Property types.
 * @type {{id: *, dataset: *, label: *, name: *, value: *, onChange: *}}
 */
CheckboxEditor.propTypes = {
  /**
	 * The id of the element.
	 * @since 1.0.0
	 */
  id: PropTypes.string.isRequired,
  /**
	 * The list of data attributes to be added to the button. This will be added to the input's dataset.
	 * Example: {name: 'email', value: 'example@domain.com'} will add data-email="example@domain.com"
	 * to the button's element
	 * @since 1.0.0
	 */
  dataset: PropTypes.array,
  /**
	 * The label of the button
	 * @since 1.0.0
	 */
  label: PropTypes.string,
  /**
	 * The name of the checkbox input.
	 * @since 1.0.0
	 */
  name: PropTypes.string,
  /**
	 * The value of the checkbox input.
	 * @since 1.0.0
	 */
  value: PropTypes.string,
  /**
	 * Applies the entered information to the preview.
	 * @param {object} event - Handles the changes made on the input
	 * @since 1.0.0
	 */
  onChange: PropTypes.func,
};

/**
 * Default values.
 * @type {{dataset: Array, label: string}}
 */
CheckboxEditor.defaultProps = {
  dataset: [],
  label: 'Checkbox Label',
};

export default CheckboxEditor;
