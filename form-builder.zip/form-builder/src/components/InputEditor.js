/**
 * @author Alan Campos
 * @version 1.0.0
 */


// React imports.
import React from 'react';
import PropTypes from 'prop-types';

// CSS imports.
import 'bootstrap/dist/css/bootstrap.css';

// Component imports.
import Input from './Input';

// Utilities
import { generateUIdWithRandom } from '../utils';

/**
 * Displays a card containing a preview of the input's current properties, along with
 * inputs that allows you to change the preview's attributes such as id, label and color.
 * The changes are applied live so the user can see what it will look like in production.
 */
class InputEditor extends React.Component {
  // This was needed because the UI was re-rendering editors that experienced no changes.
  shouldComponentUpdate(nextProps) {
    const prevProps = this.props;
    const diffId = prevProps.id !== nextProps.id;
    const diffLabel = prevProps.label !== nextProps.label;
    const diffPlaceholder = prevProps.placeholder !== nextProps.placeholder;
    return diffId || diffLabel || diffPlaceholder;
  }

  render() {
    const uid = generateUIdWithRandom();

    const {
      id,
      label,
      placeholder,
      onChange,
    } = this.props;

    return (
      <div className="card m-3" style={{ width: `${20}rem` }}>
        <div
          className="card-header text-center"
          data-toggle="collapse"
          data-target={`#collapse${uid}`}
        >
          <Input
            id={id}
            label={label}
            placeholder={placeholder}
          />
        </div>
        <ul
          className="list-group list-group-flush collapse show"
          id={`collapse${uid}`}
        >
          <li className="list-group-item">
            <Input
              id={`inputForInputIdChange${uid}`}
              label="ID"
              value={id}
              onChange={onChange}
              dataset={[
							       { name: 'state-target', value: 'id' },
							       { name: 'component-target', value: id },
						       ]}
            />
          </li>
          <li className="list-group-item">
            <Input
              id={`inputForInputLabelChange${uid}`}
              label="Label"
              value={label}
              onChange={onChange}
              dataset={[
							       { name: 'state-target', value: 'label' },
							       { name: 'component-target', value: id },
						       ]}
            />
          </li>
          <li className="list-group-item">
            <Input
              id={`inputForInputPlaceholderChange${uid}`}
              label="Placeholder"
              value={placeholder}
              onChange={onChange}
              placeholder=""
              dataset={[
							       { name: 'state-target', value: 'placeholder' },
							       { name: 'component-target', value: id },
						       ]}
            />
          </li>
        </ul>
      </div>
    );
  }
}


/**
 * Property types.
 * @type {{id: *, label: *, placeholder: *, onChange: *, dataset: *}}
 */
InputEditor.propTypes = {
  /**
	 * The id of the input.
	 * @version 1.0.0
	 */
  id: PropTypes.string.isRequired,
  /**
	 * The list of data attributes to be added to the input. This will be added to the input's dataset.
	 * Example: <code>{name: 'email', value: 'example@domain.com'}</code> will add <code>data-email="example@domain.com"</code>
	 * to the button's element
	 * @since 1.0.0
	 */
  dataset: PropTypes.array,
  /**
	 * The label for the input.
	 * @version 1.0.0
	 */
  label: PropTypes.string,
  /**
	 * The placeholder for the input.
	 * @version 1.0.0
	 */
  placeholder: PropTypes.string,
  /**
	 * Applies the entered information to the preview.
	 * @param {object} event - Handles the changes made on the input
	 * @since 1.0.0
	 */
  onChange: PropTypes.func,
};

/**
 * Default properties.
 * @type {{id: string, label: string, placeholder: string}}
 */
InputEditor.defaultProps = {
  id: 'uniqueInputId',
  label: 'Label',
  placeholder: '',
};

export default InputEditor;
