/**
 * @author Alan Campos
 * @version 1.0.0
 */

// React imports.
import React from 'react';
import PropTypes from 'prop-types';

// CSS imports.
import 'bootstrap/dist/css/bootstrap.css';

// Component imports.
import Button from './Button';
import Input from './Input';
import Select from './Select';

// Utilities
import { generateUIdWithRandom } from '../utils';

/**
 * Displays a card containing a preview of the button's current properties, along with
 * inputs that allow you to change the button's attributes such as id, label and color.
 * The changes are applied live so the user can see what it will look like in production.
 */
class ButtonEditor extends React.Component {
  // This was needed because the UI was re-rendering editors that experienced no changes.
  shouldComponentUpdate(nextProps) {
    const prevProps = this.props;
    const diffId = prevProps.id !== nextProps.id;
    const diffColor = prevProps.color !== nextProps.color;
    const diffDataset = prevProps.dataset !== nextProps.dataset;
    const diffLabel = prevProps.label !== nextProps.label;
    return diffId || diffColor || diffDataset || diffLabel;
  }

  render() {
    // Unique id generator.
    const uid = generateUIdWithRandom();

    const {
      id,
      label,
      color,
      onChange,
      dataset,
    } = this.props;

    return (
      <div className="card m-3" style={{ width: `${20}rem` }}>
        <div
          className="card-header text-center"
          data-toggle="collapse"
          data-target={`#collapse${uid}`}
        >
          <Button
            id={id}
            label={label}
            color={color}
            dataset={dataset}
          />
        </div>

        <ul className="list-group list-group-flush collapse show" id={`collapse${uid}`}>
          <li className="list-group-item">
            <Input
              id={`inputForButtonIdChange${uid}`}
              label="ID"
              value={id}
              onChange={onChange}
              dataset={[
							       { name: 'state-target', value: 'id' },
							       { name: 'component-target', value: id },
						       ]}
            />
          </li>
          <li className="list-group-item">
            <Input
              id={`inputForButtonLabelChange${uid}`}
              label="Name"
              value={label}
              placeholder=""
              onChange={onChange}
              dataset={[
							       { name: 'state-target', value: 'label' },
							       { name: 'component-target', value: id },
						       ]}
            />
          </li>
          <li className="list-group-item">
            <Select
              id={`selectForButtonColorChange${uid}`}
              label="Color"
              optionList={{
							        blue: 'Blue',
							        yellow: 'Yellow',
							        gray: 'Gray',
							        green: 'Green',
							        red: 'Red',
							        teal: 'Teal',
							        black: 'Charcoal',
							        white: 'Ice',
						        }}
              dataset={[
							        { name: 'state-target', value: 'color' },
							        { name: 'component-target', value: id },
						        ]}
              onChange={onChange}
            />
          </li>
        </ul>
      </div>
    );
  }
}

/**
 *
 * @type {{id: *, color: *, dataset: *, label: *, onChange: *}}
 */
ButtonEditor.propTypes = {
  /**
	 * The id of the element.
	 * @since 1.0.0
	 */
  id: PropTypes.string.isRequired,
  /**
	 * The color of the button in the editor's preview: <strong>blue, red, green, teal, yellow, white, black</strong>
	 * @since 1.0.0
	 */
  color: PropTypes.string,
  /**
	 * The list of data attributes to be added to the button. This will be added to the input's dataset.
	 * Example: {name: 'email', value: 'example@domain.com'} will add data-email="example@domain.com"
	 * to the button's element
	 * @since 1.0.0
	 */
  dataset: PropTypes.array,
  /**
	 * The label of the button
	 * @since 1.0.0
	 */
  label: PropTypes.string,
  /**
	 * Applies the entered information to the preview.
	 * @param {object} event - Handles the changes made on the input
	 * @since 1.0.0
	 */
  onChange: PropTypes.func,
};

/**
 * Default properties.
 * @type {{label: string, color: string, dataset: Array}}
 */
ButtonEditor.defaultProps = {
  label: 'Name',
  color: 'blue',
  dataset: [],
};

export default ButtonEditor;
