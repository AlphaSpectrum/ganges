/**
 * @author Alan Campos
 * @version 1.0.0
 */

// React
import React from 'react';
import PropTypes from 'prop-types';

// Styles
import 'bootstrap/dist/css/bootstrap.css';

// Utilities
import { applyDataset } from '../utils';

/**
 * A component that renders an HTML input element.
 */
class Input extends React.Component {
  componentDidMount() {
    const {
      id,
      dataset,
    } = this.props;
    // Apply the dataset as soon as the component is mounted.
    applyDataset(id, dataset);
  }

  componentDidUpdate() {
    const {
      id,
      dataset,
    } = this.props;
    // Update the component's dataset as soon as a new render occurs.
    applyDataset(id, dataset);
  }

  render() {
    const {
      id,
      label,
      type,
      placeholder,
      name,
      value,
      onChange,
    } = this.props;

    return (
      <div className="form-group">
        <label htmlFor={id}>
          {label}
          <input
            className="form-control"
            id={id}
            type={type}
            placeholder={placeholder}
            name={name}
            value={value}
            onChange={onChange}
          />
        </label>
      </div>
    );
  }
}


/**
 * Property types.
 * @type {{id: *, dataset: *, disabled: *, label: *, name: *, placeholder: *, required: *, type: *, value: *, onChange: *}}
 */
Input.propTypes = {
  /**
	 * The id of the input.
	 * @since 1.0.0
	 */
  id: PropTypes.string.isRequired,
  /**
	 * The list of data attributes to be added to the button. This will be added to the input's dataset.
	 * Example: {name: 'email', value: 'example@domain.com'} will add data-email="example@domain.com"
	 * to the button's element.
	 * @since 1.0.0
	 */
  dataset: PropTypes.array,
  /**
	 * Boolean value representing the disabled state of the input.
	 */
  disabled: PropTypes.bool,
  /**
	 * The label of the input.
	 * @since 1.0.0
	 */
  label: PropTypes.string,
  /**
	 * The name of the input.
	 * @since 1.0.0
	 */
  name: PropTypes.string,
  /**
	 * The placeholder for the input.
	 * @since 1.0.0
	 */
  placeholder: PropTypes.string,
  /**
	 * Boolean value representing whether the input is required or not.
	 * @since 1.0.0
	 */
  required: PropTypes.bool,
  /**
	 * The type of input. One of: <strong>text, email, tel, number</strong>
	 * @since 1.0.0
	 */
  type: PropTypes.string,
  /**
	 * The value of the input.
	 * @since 1.0.0
	 */
  value: PropTypes.string,
  /**
	 * Applies the entered information to the preview.
	 * @param {object} event - Handles the changes made on the input
	 * @since 1.0.0
	 */
  onChange: PropTypes.func,
};

/**
 * Default props.
 * @type {{label: string, type: string, disabled: boolean, placeholder: string, name: string, required: boolean, data: Array}}
 */
Input.defaultProps = {
  label: 'Label',
  type: 'text',
  disabled: false,
  placeholder: 'Placeholder',
  name: 'inputName',
  required: false,
  dataset: [],
};

export default Input;
