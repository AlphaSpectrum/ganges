import React from 'react';
import '../global/styles/bootstrap.min.css';

/**
 * @render react
 * @name Radio
 * @description An HTML radio element.
 * @example
 * <Checkbox
 *      attributes={
 *          {
 *              id: 'exampleRadio',
 *              name: 'exampleRadioName',
 *              value: 'radioValue',
 *              label: 'Radio Label',
 *              checked: false,
 *              disabled: false
 *          }
 *      }
 * />
 */
class Radio extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      id: this.props.attributes.id,
      name: this.props.attributes.name,
      value: this.props.attributes.value,
      label: this.props.attributes.label,
      checked: this.props.attributes.checked,
      disabled: this.props.attributes.disabled,
    };
  }

  componentDidMount() {
    document.getElementById(this.state.id).disabled = this.state.disabled;
    document.getElementById(this.state.id).checked = this.state.checked;
  }

  render() {
    return (
      <div className="custom-control custom-radio">
        <input
          type="radio"
          id={this.state.id}
          name={this.state.name}
          className="custom-control-input"
        />
        <label className="custom-control-label" htmlFor={this.state.id}>{this.state.label}</label>
      </div>
    );
  }
}

export default Radio;
