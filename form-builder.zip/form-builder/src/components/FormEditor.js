/**
 * @author Alan Campos
 * @version 1.0.0
 */

// React
import React from 'react';

// Components
import ButtonEditor from './ButtonEditor';

// Utilities
import InputEditor from './InputEditor';
import CheckboxEditor from './CheckboxEditor';
import TextareaEditor from './TextareaEditor';


class FormEditor extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      inputs: [
        {
          component: 'button',
          id: 'uniqueId1',
        },
        {
          component: 'input',
          id: 'uniqueId2',
        },
        {
          component: 'checkbox',
          id: 'uniqueId3',
        },
        {
          component: 'textarea',
          id: 'uniqueId4'
        },
      ],
    };

    this.handleOnChange = this.handleOnChange.bind(this);
    this.createComponent = this.createComponent.bind(this);
    this.updateStateInput = this.updateStateInput.bind(this);
  }

  handleOnChange(event) {
    this.updateStateInput(event);
  }

  createComponent(object) {
    const components = [];
    for (const i in object) {
      const element = object[i];
      switch (element.component) {
        case 'button':
          components.push(
            <ButtonEditor
              id={element.id}
              color={element.color}
              label={element.label}
              dataset={element.dataset}
              onChange={this.handleOnChange}
              key={element.id}
            />,
          );
          break;
        case 'input':
          components.push(
            <InputEditor
              id={element.id}
              label={element.label}
              dataset={element.dataset}
              placeholder={element.placeholder}
              onChange={this.handleOnChange}
              key={element.id}
            />,
          );
          break;
        case 'checkbox':
          components.push(
            <CheckboxEditor
              id={element.id}
              dataset={element.dataset}
              label={element.label}
              name={element.name}
              value={element.value}
              onChange={this.handleOnChange}
              key={element.id}
            />,
          );
          break;
        case 'textarea':
          components.push(
            <TextareaEditor
              id={element.id}
              label={element.label}
              dataset={element.dataset}
              onChange={this.handleOnChange}
              key={element.id}
            />
          );
          break;
        default:
          break;
      }
    }
    return components;
  }

  updateStateInput(event) {
    const indexToChange = event.target.getAttribute('data-state-target');
    const componentToChange = event.target.getAttribute('data-component-target');
    const stateInputsCopy = JSON.parse(JSON.stringify(this.state.inputs));
    for (const i in stateInputsCopy) {
      if (stateInputsCopy[i].id === componentToChange) {
        stateInputsCopy[i][indexToChange] = event.target.value;
      }
    }
    this.setState({ inputs: stateInputsCopy });
  }

  render() {
    const components = this.createComponent(this.state.inputs);
    return (
      <div className="container">
        <div className="row">
          <div className="col-sm-6">
            {components}
          </div>
          <div className="col-sm-4" />
        </div>
      </div>
    );
  }
}

export default FormEditor;
