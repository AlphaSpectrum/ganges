/**
 * @author Alan Campos
 * @version 1.0.0
 */

// React imports.
import React from 'react';
import PropTypes from 'prop-types';

// Styles
import 'bootstrap/dist/css/bootstrap.css';
import { applyDataset } from '../utils';


class Textarea extends React.Component {
  componentDidMount() {
	  const {
		  id,
		  required,
      disabled,
      dataset,
	  } = this.props;
    document.getElementById(id).required = required;
    document.getElementById(id).disabled = disabled;
    applyDataset(id, dataset);
  }

  componentDidUpdate() {
    const {
      id,
      dataset,
    } = this.props;
    // Update the component's dataset as soon as a new render occurs.
    applyDataset(id, dataset);
  }

  render() {
	  const {
		  id,
		  label,
		  placeholder,
		  rows,
	  } = this.props;
    return (
      <div className="form-group">
        <label htmlFor={id}>{label}</label>
        <textarea
          className="form-control"
          id={id}
          rows={rows}
          placeholder={placeholder}
        />
      </div>
    );
  }
}

Textarea.propTypes = {
  id: PropTypes.string,
  label: PropTypes.string,
  placeholder: PropTypes.string,
  rows: PropTypes.number,
  required: PropTypes.bool,
  disabled: PropTypes.bool,
};

Textarea.defaultProps = {
  id: '',
  label: 'Label',
  rows: 3,
  placeholder: 'Placeholder',
  required: false,
  disabled: false,
};
export default Textarea;
