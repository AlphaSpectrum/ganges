import React from 'react';
import PropTypes from 'prop-types';
import '../global/styles/bootstrap.min.css';

/**
 * @render react
 * @name Select
 * @description An HTML select element.
 * @example
 * <Checkbox
 *      attributes={
 *          {
 *              id: 'exampleSelect',
 *              label: 'Select Label',
 *              optionList: {
 *                  a: 'A', b: 'B', c: 'C"
 *              },
 *              multiple: false,
 *              disabled: false,
 *              size: 3
 *          }
 *      }
 * />
 */
class Select extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      id: this.props.id,
      dataset: this.props.dataset,
    };

    this.applyDataSet = this.applyDataSet.bind(this);
  }

  componentDidMount() {
    // document.getElementById(this.props.id).disabled = this.props.disabled;
    this.applyDataSet(this.state.dataset, this.state.id);
  }

  /**
	 * Extracts each data attribute from the dataset array and applies it to the element.
	 * @param dataset
	 * @param elementId
	 */
  applyDataSet(dataset, elementId) {
    for (const i in dataset) {
      // Get the index named "name" and append its value to the string `data-`
      // and set it as the attribute's name.
      // Similarly, get the value from the value index, and set it as the
      // attribute's value.
      document.getElementById(elementId).setAttribute(`data-${dataset[i].name}`, dataset[i].value);
    }
  }

  render() {
    // Array to hold each `<option>` element for the list.
    const optionElList = [];

    // Go through each item in the `optionList` and push it to an array.
    for (const key in this.props.optionList) {
      optionElList.push(<option key={key} value={key}>{this.props.optionList[key]}</option>);
    }

    // If the select list allows multiple.
    if (this.props.multiple) {
      return (
        <div className="form-group">
          <label htmlFor={this.props.id}>{this.props.label}</label>
          <select
            multiple
            className="custom-select"
            id={this.props.id}
            size={this.props.size}
            onChange={this.props.onChange}
          >
            {optionElList}
          </select>
        </div>
      );
    }

    // If it's a dropdown select list.
    return (
      <div className="form-group">
        <label htmlFor={this.props.id}>{this.props.label}</label>
        <select
          className="custom-select"
          id={this.props.id}
          onChange={this.props.onChange}
        >
          {optionElList}
        </select>
      </div>
    );
  }
}

/**
 * Expected props.
 * @type {{id: *, label: *, size: *, disabled: *, multiple: *, optionList: *, dataset: *, onchange: *}}
 */
Select.propTypes = {
  id: PropTypes.string.isRequired,
  dataset: PropTypes.array,
  disabled: PropTypes.bool,
  label: PropTypes.string,
  multiple: PropTypes.bool,
  onchange: PropTypes.func,
  optionList: PropTypes.object,
  size: PropTypes.number,
};

/**
 * Default props.
 * @type {{label: string, size: number, disabled: boolean, multiple: boolean, optionList: {a: string, b: string, c: string}, dataset: Array}}
 */
Select.defaultProps = {
  label: 'Label',
  size: 3,
  disabled: false,
  multiple: false,
  optionList: { a: 'A', b: 'B', c: 'C' },
  dataset: [],
};

export default Select;
