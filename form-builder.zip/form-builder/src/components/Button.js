/**
 * @author Alan Campos
 * @version 1.0.0
 */

// React imports.
import React from 'react';
import PropTypes from 'prop-types';

// Styles
import 'bootstrap/dist/css/bootstrap.css';
import { applyDataset, setStateForDisabled } from '../utils';


/**
 * An HTML button input.
 */
class Button extends React.Component {
  constructor(props) {
    super(props);
    this.getColorClass = this.getColorClass.bind(this);
    this.getSizeClass = this.getSizeClass.bind(this);
  }

  componentDidMount() {
    const {
      id,
      dataset,
      disabled,
    } = this.props;
    // Apply the dataset as soon as the component is mounted.
    applyDataset(id, dataset);
    setStateForDisabled(id, disabled);
  }

  componentDidUpdate() {
    const {
      id,
      dataset,
    } = this.props;
    // Update the component's dataset as soon as a new render occurs.
    applyDataset(id, dataset);
  }

  /**
	 * @desc Maps the color to its corresponding CSS class name.
	 * @param {string} color - The name of color.
	 * @returns {string} - A Bootstrap 4 CSS class name that contextually represents the color. Possible
	 *                     values: {warning | secondary | primary | success | danger | info | dark | light}.
	 *                     The default value is `light`.
	 * @since 1.0.0
	 */
  getColorClass(color) {
    switch (color) {
      case 'yellow':
        return 'warning';
      case 'gray':
      case 'grey':
        return 'secondary';
      case 'blue':
        return 'primary';
      case 'green':
        return 'success';
      case 'red':
        return 'danger';
      case 'teal':
        return 'info';
      case 'black':
        return 'dark';
      case 'white':
        return 'light';
      default:
        return 'light';
    }
  }

  /**
	 * @desc Maps the size to its corresponding CSS size class name.
	 * @param {string} size - The user readable size string.
	 * @returns {string} A Bootstrap 4 CSS class name that contextually represents the size. Possible
	 *                     values: {btn-sm | btn-lg }. The default value is null which represents the size medium.
	 * @since 1.0.0
	 */
  getSizeClass(size) {
    switch (size) {
      case 'sm':
        return 'btn-sm';
      case 'lg':
        return 'btn-lg';
      case 'md':
        return '';
      default:
        return '';
    }
  }

  render() {
    const {
      id,
      type,
      color,
      size,
      label,
      disabled,
    } = this.props;

    // If `disabled` is true we render a button that is disabled instead.
    if (disabled) {
      return (
        <button
          className={`m-1 btn btn-${this.getColorClass(color)} ${this.getSizeClass(size)}`}
          id={id}
          key={id}
          type={type}
          disabled="true"
        >
          {label}
        </button>
      );
    }
    return (
      <button
        className={`m-1 btn btn-${this.getColorClass(color)} ${this.getSizeClass(size)}`}
        id={id}
        key={id}
        type={type}
      >
        {label}
      </button>
    );
  }
}


/**
 * @desc Property types.
 * @type {{color: *, disabled: *, id: *, label: *, size: *, type: *, dataset: *}}
 */
Button.propTypes = {
  /**
	 * The id of the element.
	 * @since 1.0.0
	 */
  id: PropTypes.string.isRequired,
  /**
	 * The color of the button: <strong> blue, red, green, teal, yellow, white, black </strong>
	 * @since 1.0.0
	 */
  color: PropTypes.string,
  /**
	 * The list of <em>data</em> attributes to be added to the button.
	 * This will be added to the input's dataset.
	 * <br>
	 * Example: <code>{name: 'email', value: 'example@domain.com'}</code> will add
	 * <code>data-email="example@domain.com"</code> to the button's element.
	 * @since 1.0.0
	 */
  dataset: PropTypes.array,
  /**
	 * Whether the button is disabled or not.
	 * @since 1.0.0
	 */
  disabled: PropTypes.bool,
  /**
	 * The label for the button.
	 * @since 1.0.0
	 */
  label: PropTypes.string,
  /**
	 * The size of the button: <strong>sm, md, lg</strong>
	 * @since 1.0.0
	 */
  size: PropTypes.string,
  /**
	 * The type of button: <strong>submit, reset</strong>
	 * @since 1.0.0
	 */
  type: PropTypes.string,
};

Button.defaultProps = {
  label: 'Label',
  type: 'submit',
  color: 'blue',
  disabled: false,
  dataset: [],
  size: 'md',
};

export default Button;
