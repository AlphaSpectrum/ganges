/**
 * @author Alan Campos
 * @version 1.0.0
 */

import React from 'react';
import PropTypes from 'prop-types';
import 'bootstrap/dist/css/bootstrap.css';
import { setStateForDisabled, setStateForChecked, applyDataset } from '../utils';

/**
 * An HTML checkbox input.
 */
class Checkbox extends React.Component {
  componentDidMount() {
    const {
      id,
      disabled,
      checked,
      dataset,
    } = this.props;
    // Either disable or enable the button based on the state of `disabled`.
    setStateForDisabled(id, disabled);
    // Either check or uncheck the box based on the state of `checked`.
    setStateForChecked(id, checked);
    // Apply the element's data set if provided.
    applyDataset(id, dataset);
  }

  componentDidUpdate() {
    const {
      id,
      dataset,
    } = this.props;
    // Make sure we are updating the element's data set every time there is an update.
    applyDataset(id, dataset);
  }

  render() {
    const {
      id,
      label,
      name,
      value,
    } = this.props;

    return (
      <div className="custom-control custom-checkbox">
        <input
          type="checkbox"
          className="custom-control-input"
          id={id}
          name={name}
          value={value}
        />
        <label
          className="custom-control-label"
          htmlFor={id}
        >
          {label}
        </label>
      </div>
    );
  }
}

/**
 * @desc Property types.
 * @type {{id: *, checked: *, dataset: *, disabled: *, label: *, value: *}}
 */
Checkbox.propTypes = {
  /**
	 * The id of the element.
	 * @since 1.0.0
	 */
  id: PropTypes.string.isRequired,
  /**
	 * Whether the checkbox is checked or not.
	 * @since 1.0.0
	 */
  checked: PropTypes.boolean,
  /**
	 * The list of <em>data</em> attributes to be added to the checkbox.
	 * This will be added to the input's dataset.
	 * <br>
	 * Example: <code>{name: 'email', value: 'example@domain.com'}</code> will add
	 * <code>data-email="example@domain.com"</code> to checkbox element.
	 * @since 1.0.0
	 */
  dataset: PropTypes.array,
  /**
	 * Whether the checkbox is disabled or not.
	 * @since 1.0.0
	 */
  disabled: PropTypes.boolean,
  /**
	 * The label for the checkbox.
	 * @since 1.0.0
	 */
  label: PropTypes.string,
  /**
	 * The name of the checkbox input.
	 * @since 1.0.0
	 */
  name: PropTypes.string,
  /**
	 * The value of the checkbox.
	 * @since 1.0.0
	 */
  value: PropTypes.string,
};

Checkbox.defaultProps = {
  checked: false,
  dataset: [],
  disabled: false,
  label: 'Checkbox Label',
  name: 'checkbox-example-name',
  value: 'checkbox-example-value',
};

export default Checkbox;
