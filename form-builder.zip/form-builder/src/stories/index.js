import React from 'react';

import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { linkTo } from '@storybook/addon-links';

import 'bootstrap/dist/css/bootstrap.css';
import Input from '../components/Input';
import ButtonEditor from '../components/ButtonEditor';
import Button from '../components/Button';

storiesOf('Button', module).add('to Storybook', () => <Button id='uniqueButtonId'/>);
storiesOf('Button Editor', module).add('to Storybook', () => <ButtonEditor id='uniqueButtonEditorId'/>);

